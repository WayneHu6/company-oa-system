// 用户管理
function feedbackManage() {

	layui.use(['form', 'table'], function() {
		var $ = layui.jquery,
			form = layui.form,
			table = layui.table;
		var datas = {
			"token": window.localStorage.getItem("token"),
			"userid": window.localStorage.getItem("userid"),
		};

		$.ajax({
			url: baseurl + "feedback/list",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "1") {
					var d = data.data;
					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'id',
									width: 80,
									title: '用户ID'
								},
								{
									field: 'name',
									width: 100,
									title: '用户名',
									align: "center",
									templet:function(data){
										return data.user.name
									}
								},
								{
									field: 'tel',
									width: 150,
									title: '电话号码',
									align: "center",
									templet:function(data){
										return data.user.tel
									}
								},
								{
									field: 'content',
									width: 300,
									title: '内容',
									align: "center"
								},
								{
									field: 'sendTime',
									width: 300,
									title: '提交时间',
									align: "center"
								},
								
								// {
								// 	title: '操作',
								// 	minWidth: 300,
								// 	toolbar: '#currentTableBar',
								// 	align: "center"
								// }
							]
						],
						limits: [5, 10, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});


				} else {
					layer.alert(data.msg);
				}
			},
			error: function(data) {
				alertHttpError();
			}
		});

	});
}













