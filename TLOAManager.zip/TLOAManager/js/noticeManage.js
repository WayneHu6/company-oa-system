// 通知公告管理
function noticeManage() {

	layui.use(['form', 'table'], function() {
		var $ = layui.jquery,
			form = layui.form,
			table = layui.table;
			


		var datas = {
			"token": window.localStorage.getItem("token"),
			"userid": window.localStorage.getItem("userid"),
		};

		$.ajax({
			url: baseurl + "notice/list",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "1") {
					var d = data.data;
					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'id',
									width: 80,
									title: '通知公告ID'
								},
								{
									field: 'title',
									width: 300,
									title: '标题',
									edit: 'text',
									align: "center"
								},
								{
									field: 'content',
									title: '内容',
									width:500,
									edit: 'text',
									align: "center"
								},
								
								{
									field: 'type',
									width: 60,
									title: '类别',
									align: "center",
									templet: function(data){
										var sext = "公告";
										if(data.type == "0"){
											sext = "通知";
										}
										return "<span>"+sext+"</span>";
									}
								},
								{
									field: 'sendTime',
									width: 200,
									title: '发布时间',
									align: "center"
								},
								{
								field: 'updateTime',
									width: 200,
									title: '更新时间',
									align: "center"
								},
								{
									title: '操作',
									minWidth: 300,
									toolbar: '#currentTableBar',
									align: "center"
								}
							]
						],
						limits: [5, 10, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});


				} else {
					layer.alert(data.msg);
				}
			},
			error: function(data) {
				alertHttpError();
			}
		});




		/**
		 * toolbar监听事件
		 */
		table.on('toolbar(currentTableFilter)', function(obj) {
			if (obj.event === 'add') { // 监听添加操作
				var index = layer.open({
					title: '添加',
					type: 2,
					shade: 0.2,
					maxmin: true,
					shadeClose: true,
					area: ['100%', '100%'],
					content: 'add.html',
				});
				$(window).on("resize", function() {
					layer.full(index);
				});
			}

		});


        // 监听搜索操作
        form.on('submit(data-search-btn)', function (data) {
			console.log(data);
           var datas = {
			   "content":data.field.s_tel,
			   };
           $.ajax({
           	url: baseurl + "notice/listByContent?content="+data.field.s_tel,
           	data: JSON.stringify(datas),
           	type: "post",
           	dataType: "json",
           	headers: {
           		'Content-Type': 'application/json;charset=utf-8'
           	}, //接口json格式
           	success: function(data) {
				if (data.code == "1") {
					var d = data.data;
					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'id',
									width: 80,
									title: '通知公告ID'
								},
								{
									field: 'title',
									width: 300,
									title: '标题',
									edit: 'text',
									align: "center"
								},
								{
									field: 'content',
									title: '内容',
									width:500,
									edit: 'text',
									align: "center"
								},
								
								{
									field: 'type',
									width: 60,
									title: '类别',
									align: "center",
									templet: function(data){
										var sext = "公告";
										if(data.type == "0"){
											sext = "通知";
										}
										return "<span>"+sext+"</span>";
									}
								},
								{
									field: 'sendTime',
									width: 200,
									title: '发布时间',
									align: "center"
								},
								{
								field: 'updateTime',
									width: 200,
									title: '更新时间',
									align: "center"
								},
								{
									title: '操作',
									minWidth: 300,
									toolbar: '#currentTableBar',
									align: "center"
								}
							]
						],
						limits: [10, 15, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});
				
				
				} else {
					layer.alert(data.msg);
				}
				
				
           	},
           	error: function(data) {
           		alertHttpError();
           	}
           });
		   



            return false;
        });
		
		

		//监听单元格编辑
		table.on('edit(currentTableFilter)', function(obj) {
			var value = obj.value //得到修改后的值
				,
				data = obj.data //得到所在行所有键值
				,
				field = obj.field; //得到字段

			var datas = "{\""+ field + "\":\""+ value+"\",\"id\":\""+data.id+"\"}";

			$.ajax({
				url: baseurl + "notice/update",
				data: JSON.parse(JSON.stringify(datas)),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "1") {
						layer.msg('修改成功', function() {
							// obj.del();
							// layer.close(index);
							location.reload(1);
						});
					} else {
						layer.alert(data.msg);
					}
				},
				error: function(data) {
					alertHttpError();
				}
			});



		});



		table.on('tool(currentTableFilter)', function(obj) {
			var data = obj.data;
			if (obj.event === 'edit') {
				layer.confirm('直接点击你要编辑的字段即可实现编辑保存');
				return false;
			} else if (obj.event === 'delete') {
				// 执行删除通知公告操作
				layer.confirm('真的要删除这个通知公告吗？', function(index) {


					var datas = {
						"id": data.id
					};

					$.ajax({
						url: baseurl + "notice/delete?id="+data.id,
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('删除成功', function() {
									obj.del();
									layer.close(index);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			}



		});




	});
}















// 添加
function add() {




	layui.use(['form',"upload"], function() {
		var form = layui.form,
			layer = layui.layer,
			upload = layui.upload,
			$ = layui.$;
			
			


		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认添加吗???", {
				title: '确认添加'
			}, function() {
				
					var datas = {
						        "title":data.title,
						        "content":data.content,
						        "type":data.type,
					};
					
					$.ajax({
						url: baseurl + "notice/save",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('添加成功', function() {
									// 关闭弹出层
									layer.close(index);
					
									var iframeIndex = parent.layer
										.getFrameIndex(window.name);
									parent.layer.close(iframeIndex);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});
					
				
			});

			return false;
		});

	});

}
