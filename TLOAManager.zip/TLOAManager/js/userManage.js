// 用户管理
function userManage() {

	layui.use(['form', 'table'], function() {
		var $ = layui.jquery,
			form = layui.form,
			table = layui.table;
		var datas = {
			"token": window.localStorage.getItem("token"),
			"userid": window.localStorage.getItem("userid"),
		};

		$.ajax({
			url: baseurl + "user/list",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "1") {
					var d = data.data;
					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'id',
									width: 80,
									title: '用户ID'
								},
								{
									field: 'name',
									width: 100,
									title: '用户名',
									edit: 'text',
									align: "center"
								},
								{
									field: 'psd',
									width: 150,
									title: '密码',
									edit: 'text',
									align: "center"
								},
								{
									field: 'idCard',
									width: 100,
									title: '身份证号码',
									edit: 'text',
									align: "center"
								},
								{
									field: 'tel',
									title: '电话号码',
									width:120,
									edit: 'text',
									align: "center"
								},
								{
									field: 'idCard',
									width: 200,
									title: '身份证号码',
									align: "center",
									edit: 'text'
								},
								{
									field: 'idcardImg1',
									width: 200,
									title: '身份证正面照片',
									align: "center",
									templet:"#imgtmp1"
								},
								{
									field: 'idcardImg2',
									width: 200,
									title: '身份证正面照片',
									align: "center",
									templet:"#imgtmp2"
								},
								{
									field: 'sex',
									width: 60,
									title: '性别',
									align: "center",
									templet: function(data){
										var sext = "男";
										if(data.sex == "2"){
											sext = "女";
										}
										return "<span>"+sext+"</span>";
									}
								},
								{
									field: 'jobNumber',
									width: 150,
									title: '工号',
									edit: 'text',
									align: "center"
								},
								{
									field: 'icon',
									width: 150,
									title: '头像',
									align: "center",
									templet:"#imgtmpUser"
								},
								{
								field: 'address',
									width: 250,
									title: '地址',
									edit: 'text',
									align: "center"
								},
								
								{
									field: 'state',
									width: 120,
									title: '账号状态',
									align: "center",
									templet: function(data){
										if(data.state == "0"){
											tmp = "注册申请待审核";
											return "<span style='color:#ffaa00'>"+tmp+"</span>";
										}
										if(data.state == "1"){
											tmp = "正常登录";
											return "<span style='color:#55ff7f'>"+tmp+"</span>";
										}
										if(data.state == "2"){
											tmp = "员工离职";
											return "<span style='color:#ff0000'>"+tmp+"</span>";
										}
									}
									
								},
								{
									field:"position",
									title: '员工职位',
									minWidth: 120,
									align: "center",
									templet:function(data){
										return "<span>"+data.profession.position+"</span>";
									}
								},
							
								
								{
									title: '操作',
									minWidth: 300,
									toolbar: '#currentTableBar',
									align: "center"
								}
							]
						],
						limits: [5, 10, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});


				} else {
					layer.alert(data.msg);
				}
			},
			error: function(data) {
				alertHttpError();
			}
		});




		/**
		 * toolbar监听事件
		 */
		table.on('toolbar(currentTableFilter)', function(obj) {
			if (obj.event === 'add') { // 监听添加操作
				var index = layer.open({
					title: '添加',
					type: 2,
					shade: 0.2,
					maxmin: true,
					shadeClose: true,
					area: ['100%', '100%'],
					content: 'add.html',
				});
				$(window).on("resize", function() {
					layer.full(index);
				});
			}

		});


        // 监听搜索操作
        form.on('submit(data-search-btn)', function (data) {
			console.log(data);
           var datas = {
			   "tel":data.field.s_tel,
			   };
           $.ajax({
           	url: baseurl + "user/listByCondition?condition="+data.field.s_tel,
           	data: JSON.stringify(datas),
           	type: "post",
           	dataType: "json",
           	headers: {
           		'Content-Type': 'application/json;charset=utf-8'
           	}, //接口json格式
           	success: function(data) {
				if (data.code == "1") {
					var d = data.data;
					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'id',
									width: 80,
									title: '用户ID'
								},
								{
									field: 'name',
									width: 100,
									title: '用户名',
									edit: 'text',
									align: "center"
								},
								{
									field: 'psd',
									width: 150,
									title: '密码',
									edit: 'text',
									align: "center"
								},
								{
									field: 'idCard',
									width: 100,
									title: '身份证号码',
									edit: 'text',
									align: "center"
								},
								{
									field: 'tel',
									title: '电话号码',
									width:120,
									edit: 'text',
									align: "center"
								},
								{
									field: 'idCard',
									width: 200,
									title: '身份证号码',
									align: "center",
									edit: 'text'
								},
								{
									field: 'idcardImg1',
									width: 200,
									title: '身份证正面照片',
									align: "center",
									templet:"#imgtmp1"
								},
								{
									field: 'idcardImg2',
									width: 200,
									title: '身份证正面照片',
									align: "center",
									templet:"#imgtmp2"
								},
								{
									field: 'sex',
									width: 60,
									title: '性别',
									align: "center",
									templet: function(data){
										var sext = "男";
										if(data.sex == "0"){
											sext = "女";
										}
										return "<span>"+sext+"</span>";
									}
								},
								{
									field: 'jobNumber',
									width: 150,
									title: '工号',
									edit: 'text',
									align: "center"
								},
								{
									field: 'icon',
									width: 150,
									title: '头像',
									align: "center",
									templet:"#imgtmpUser"
								},
								{
								field: 'address',
									width: 250,
									title: '地址',
									edit: 'text',
									align: "center"
								},
								
								{
									field: 'state',
									width: 120,
									title: '账号状态',
									align: "center",
									templet: function(data){
										if(data.state == "0"){
											tmp = "注册申请待审核";
											return "<span style='color:#ffaa00'>"+tmp+"</span>";
										}
										if(data.state == "1"){
											tmp = "正常登录";
											return "<span style='color:#55ff7f'>"+tmp+"</span>";
										}
										if(data.state == "2"){
											tmp = "员工离职";
											return "<span style='color:#ff0000'>"+tmp+"</span>";
										}
									}
									
								},
								
							
								
								{
									title: '操作',
									minWidth: 300,
									toolbar: '#currentTableBar',
									align: "center"
								}
							]
						],
						limits: [10, 15, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});
				
				
				} else {
					layer.alert(data.msg);
				}
				
				
           	},
           	error: function(data) {
           		alertHttpError();
           	}
           });
		   



            return false;
        });
		
		

		//监听单元格编辑
		table.on('edit(currentTableFilter)', function(obj) {
			var value = obj.value //得到修改后的值
				,
				data = obj.data //得到所在行所有键值
				,
				field = obj.field; //得到字段

			var datas = "{\""+ field + "\":\""+ value+"\",\"id\":\""+data.id+"\"}";

			$.ajax({
				url: baseurl + "user/update",
				data: JSON.parse(JSON.stringify(datas)),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "1") {
						layer.msg('修改成功', function() {
							// obj.del();
							// layer.close(index);
							location.reload(1);
						});
					} else {
						layer.alert(data.msg);
					}
				},
				error: function(data) {
					alertHttpError();
				}
			});



		});



		table.on('tool(currentTableFilter)', function(obj) {
			var data = obj.data;
			if (obj.event === 'edit') {
				layer.confirm('直接点击你要编辑的字段即可实现编辑保存');
				return false;
			} else if (obj.event === 'pass') {
				// 执行删除用户操作
				layer.confirm('确定此账号为本公司员工注册通过审核吗？', function(index) {
					var datas = {
						"id": data.id,
						"state": "1",
					};

					$.ajax({
						url: baseurl + "user/update",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('操作成功', function() {
									// 刷新页面
									location.reload(1);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			}else if (obj.event === 'leave') {
				// 执行删除用户操作
				layer.confirm('确定此员工已离职,设置为离职状态吗？', function(index) {
					var datas = {
						"id": data.id,
						"state": "2",
					};

					$.ajax({
						url: baseurl + "user/update",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('操作成功', function() {
									// 刷新页面
									location.reload(1);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			}else if (obj.event === 'setPosition') {
				// alert(JSON.stringify(obj.data.id))
				var uid = obj.data.id;
				// 打开设置职位信息的页面
				var index = layer.open({
					title: '添加',
					type: 2,
					shade: 0.2,
					maxmin: true,
					shadeClose: true,
					area: ['100%', '100%'],
					content: 'setPosition.html?userid='+uid,
				});
				$(window).on("resize", function() {
					layer.full(index);
				});
			} else if (obj.event === 'delete') {
				// 执行删除用户操作
				layer.confirm('真的要删除这个用户吗？', function(index) {
					var datas = {
						"id": data.id
					};

					$.ajax({
						url: baseurl + "user/delete?id="+data.id,
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('删除成功', function() {
									obj.del();
									layer.close(index);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			}



		});




	});
}















// 添加
function add() {




	layui.use(['form',"upload"], function() {
		var form = layui.form,
			layer = layui.layer,
			upload = layui.upload,
			$ = layui.$;
			
			


		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认添加吗???", {
				title: '确认添加'
			}, function() {
				
					var datas = {
						        "tel":data.tel,
						        "psd":data.password,
								"jobNumber":data.jobNumber,
								"state":"1", // 设置用户状态为正常可灯枯状态,
								 "profession": {
								    "des": data.des,
								    "position": data.position,
								  },
					};
					
					$.ajax({
						url: baseurl + "user/save",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('添加成功', function() {
									// 关闭弹出层
									layer.close(index);
					
									var iframeIndex = parent.layer
										.getFrameIndex(window.name);
									parent.layer.close(iframeIndex);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});
					
				
			});

			return false;
		});

	});

}


function GetQueryValue(queryName) {
    var query = decodeURI(window.location.search.substring(1));
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == queryName) { return pair[1]; }
    }
    return null;
}


// 设置职位
function setPosition() {




	layui.use(['form',"upload"], function() {
		var form = layui.form,
			layer = layui.layer,
			upload = layui.upload,
			$ = layui.$;
			
			
			// 异步加载用户职位信息
			var datas = {};
			// 异步加载折扣信息
			$.ajax({
				url: baseurl + "user/getUserByid?userid="+GetQueryValue("userid"),
				data: JSON.stringify(datas),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "1") {
						
						$("#showTel").val(data.data.tel);
						$("#showPosition").val(data.data.profession.position);
						$("#showDes").val(data.data.profession.des);
					} else {
						layer.alert(data.msg);
					}
				},
				error: function(data) {
					alertHttpError();
				}
			});
			
			
			


		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认修改吗???", {
				title: '确认修改'
			}, function() {
				
					var datas = {
						        "tel":data.tel,
								 "profession": {
								    "des": data.des,
								    "position": data.position,
								  },
					};
					
					$.ajax({
						url: baseurl + "user/setPositionByTel",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('操作成功', function() {
									// 关闭弹出层
									layer.close(index);
					
									var iframeIndex = parent.layer
										.getFrameIndex(window.name);
									parent.layer.close(iframeIndex);
									// 刷新页面
									location.reload(1);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});
					
				
			});

			return false;
		});

	});

}
