// 用户管理
function toolManage() {

	layui.use(['form', 'table'], function() {
		var $ = layui.jquery,
			form = layui.form,
			table = layui.table;
		var datas = {
			"token": window.localStorage.getItem("token"),
			"userid": window.localStorage.getItem("userid"),
		};

		$.ajax({
			url: baseurl + "tool/list",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "1") {
					var d = data.data;
					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'id',
									width: 80,
									title: 'ID'
								},
								{
									field: 'img',
									width: 200,
									title: '图片',
									align: "center",
									templet: "#imgtmp"
								},
								{
									field: 'name',
									width: 100,
									title: '工具名称',
									edit: 'text',
									align: "center"
								},
								{
									field: 'des',
									width: 150,
									title: '描述',
									edit: 'text',
									align: "center"
								},
								{
									field: 'price',
									width: 100,
									title: '单价',
									edit: 'text',
									align: "center"
								},
								{
									field: 'state',
									width: 120,
									title: '物品状态',
									align: "center",
									templet: function(data) {
										if (data.state == "0") {
											tmp = "空闲";
											return "<span style='color:#55ff7f'>" +
												tmp + "</span>";
										}
										if (data.state == "1") {
											tmp = "借出";
											return "<span style='color:#ff0000'>" +
												tmp + "</span>";
										}
									}

								},
								{
									title: '操作',
									minWidth: 300,
									toolbar: '#currentTableBar',
									align: "center"
								}
							]
						],
						limits: [5, 10, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});


				} else {
					layer.alert(data.msg);
				}
			},
			error: function(data) {
				alertHttpError();
			}
		});




		/**
		 * toolbar监听事件
		 */
		table.on('toolbar(currentTableFilter)', function(obj) {
			if (obj.event === 'add') { // 监听添加操作
				var index = layer.open({
					title: '添加',
					type: 2,
					shade: 0.2,
					maxmin: true,
					shadeClose: true,
					area: ['100%', '100%'],
					content: 'add.html',
				});
				$(window).on("resize", function() {
					layer.full(index);
				});
			}

		});


		// 监听搜索操作
		form.on('submit(data-search-btn)', function(data) {
			console.log(data);
			var datas = {
				"tel": data.field.s_tel,
			};
			$.ajax({
				url: baseurl + "tool/listByCondition?condition=" + data.field.s_tel,
				data: JSON.stringify(datas),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "1") {
						var d = data.data;
						table.render({
							elem: '#currentTableId',
							data: d,
							toolbar: '#toolbarDemo',
							defaultToolbar: ['filter', 'exports', 'print', {
								title: '提示',
								layEvent: 'LAYTABLE_TIPS',
								icon: 'layui-icon-tips'
							}],
							cols: [
								[{
										field: 'id',
										width: 80,
										title: 'ID'
									},
									{
										field: 'img',
										width: 200,
										title: '图片',
										align: "center",
										templet: "#imgtmp"
									},
									{
										field: 'name',
										width: 100,
										title: '工具名称',
										edit: 'text',
										align: "center"
									},
									{
										field: 'des',
										width: 150,
										title: '描述',
										edit: 'text',
										align: "center"
									},
									{
										field: 'price',
										width: 100,
										title: '单价',
										edit: 'text',
										align: "center"
									},
									{
										field: 'state',
										width: 120,
										title: '物品状态',
										align: "center",
										templet: function(data) {
											if (data.state == "0") {
												tmp = "空闲";
												return "<span style='color:#55ff7f'>" +
													tmp + "</span>";
											}
											if (data.state == "1") {
												tmp = "借出";
												return "<span style='color:#ff0000'>" +
													tmp + "</span>";
											}
										}

									},
									{
										title: '操作',
										minWidth: 300,
										toolbar: '#currentTableBar',
										align: "center"
									}
								]
							],
							limits: [10, 15, 20, 25, 50, 100],
							limit: d.length,
							page: true,
							skin: 'line'
						});


					} else {
						layer.alert(data.msg);
					}


				},
				error: function(data) {
					alertHttpError();
				}
			});




			return false;
		});



		//监听单元格编辑
		table.on('edit(currentTableFilter)', function(obj) {
			var value = obj.value //得到修改后的值
				,
				data = obj.data //得到所在行所有键值
				,
				field = obj.field; //得到字段

			var datas = "{\"" + field + "\":\"" + value + "\",\"id\":\"" + data.id + "\"}";

			$.ajax({
				url: baseurl + "tool/update",
				data: JSON.parse(JSON.stringify(datas)),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "1") {
						layer.msg('修改成功', function() {
							// obj.del();
							// layer.close(index);
							location.reload(1);
						});
					} else {
						layer.alert(data.msg);
					}
				},
				error: function(data) {
					alertHttpError();
				}
			});



		});



		table.on('tool(currentTableFilter)', function(obj) {
			var data = obj.data;
			if (obj.event === 'edit') {
				layer.confirm('直接点击你要编辑的字段即可实现编辑保存');
				return false;
			} else if (obj.event === 'free') {
				// 执行删除用户操作
				layer.confirm('确定设置此工具状态为空闲吗？', function(index) {
					var datas = {
						"id": data.id,
						"state": "0",
					};

					$.ajax({
						url: baseurl + "tool/update",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('操作成功', function() {
									// 刷新页面
									location.reload(1);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			} else if (obj.event === 'unfree') {
				// 执行删除用户操作
				layer.confirm('确定设置此工具状态为借出吗？', function(index) {
					var datas = {
						"id": data.id,
						"state": "1",
					};

					$.ajax({
						url: baseurl + "tool/update",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('操作成功', function() {
									// 刷新页面
									location.reload(1);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			} else if (obj.event === 'delete') {
				// 执行删除用户操作
				layer.confirm('真的要删除吗？', function(index) {
					var datas = {
						"id": data.id
					};

					$.ajax({
						url: baseurl + "tool/delete?id=" + data.id,
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('删除成功', function() {
									obj.del();
									layer.close(index);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			}



		});




	});
}















// 添加
function add() {




	layui.use(['form', "upload"], function() {
		var form = layui.form,
			layer = layui.layer,
			upload = layui.upload,
			$ = layui.$;

		// 上传文件
		var path = ""; // 文件路径
		var code = "0"; // 操作码

		upload.render({
			elem: '#test10',
			url: baseurl + "common/upload", // 上传接口

			done: function(res) {
				if (res.code == 1) {
					layer.msg('上传成功');
					path = baseurl + "common/download?name=" + res.data;
					code = res.code;
					console.log("---" + path);
					layui.$('#showIconUrl').removeClass('layui-hide').find('span').text(path);
					layui.$('#uploadDemoView').removeClass('layui-hide').find('img').attr('src',
						path);
				} else {
					layer.msg('上传失败' + res.msg);
				}

			}
		});






		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认添加吗???", {
				title: '确认添加'
			}, function() {

				if (code == 1) {

					var datas = {
						"des": data.des,
						"img": path,
						"name": data.name,
						"price": data.price,
						"state": "0",
					};

					$.ajax({
						url: baseurl + "tool/save",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('添加成功', function() {
									// 关闭弹出层
									layer.close(index);

									var iframeIndex = parent.layer
										.getFrameIndex(window.name);
									parent.layer.close(iframeIndex);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				} else {
					layer.alert("请先上传工具图片");
				}







			});

			return false;
		});

	});

}
