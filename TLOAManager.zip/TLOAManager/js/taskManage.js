// 用户管理
function taskManage() {

	layui.use(['form', 'table'], function() {
		var $ = layui.jquery,
			form = layui.form,
			table = layui.table;
			
			
		var datas = {
			"token": window.localStorage.getItem("token"),
			"userid": window.localStorage.getItem("userid"),
		};

		$.ajax({
			url: baseurl + "task/list",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "1") {
					var d = data.data;
					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'id',
									width: 80,
									title: 'ID'
								},
								{
									field: 'name',
									width: 150,
									title: '任务名称',
									edit: 'text',
									align: "center"
								},
								{
									field: 'content',
									width: 300,
									title: '任务内容',
									edit: 'text',
									align: "center"
								},
								{
									field: 'address',
									width: 200,
									title: '项目执行地点',
									edit: 'text',
									align: "center"
								},
								{
									field: 'type',
									title: '任务类型',
									width:120,
									edit: 'text',
									align: "center"
								},
								{
									field: 'startTime',
									width: 200,
									title: '任务开始时间',
									align: "center",
									edit: 'text'
								},	
								{
									title: '操作',
									minWidth: 300,
									toolbar: '#currentTableBar',
									align: "center"
								}
							]
						],
						limits: [5, 10, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});


				} else {
					layer.alert(data.msg);
				}
			},
			error: function(data) {
				alertHttpError();
			}
		});




		/**
		 * toolbar监听事件
		 */
		table.on('toolbar(currentTableFilter)', function(obj) {
			if (obj.event === 'add') { // 监听添加操作
				var index = layer.open({
					title: '添加',
					type: 2,
					shade: 0.2,
					maxmin: true,
					shadeClose: true,
					area: ['100%', '100%'],
					content: 'add.html',
				});
				$(window).on("resize", function() {
					layer.full(index);
				});
			}

		});


        // 监听搜索操作
        form.on('submit(data-search-btn)', function (data) {
			console.log(data);
           var datas = {
			   "tel":data.field.s_tel,
			   };
           $.ajax({
           	url: baseurl + "task/listByCondition?condition="+data.field.s_tel,
           	data: JSON.stringify(datas),
           	type: "post",
           	dataType: "json",
           	headers: {
           		'Content-Type': 'application/json;charset=utf-8'
           	}, //接口json格式
           	success: function(data) {
				if (data.code == "1") {
					var d = data.data;
					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'id',
									width: 80,
									title: 'ID'
								},
								{
									field: 'name',
									width: 100,
									title: '任务名称',
									edit: 'text',
									align: "center"
								},
								{
									field: 'content',
									width: 150,
									title: '任务内容',
									edit: 'text',
									align: "center"
								},
								{
									field: 'address',
									width: 100,
									title: '项目执行地点',
									edit: 'text',
									align: "center"
								},
								{
									field: 'type',
									title: '电话号码',
									width:120,
									edit: 'text',
									align: "center"
								},
								{
									field: 'startTime',
									width: 200,
									title: '任务开始时间',
									align: "center",
									edit: 'text'
								},	
								{
									title: '操作',
									minWidth: 300,
									toolbar: '#currentTableBar',
									align: "center"
								}
							]
						],
						limits: [10, 15, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});
				
				
				} else {
					layer.alert(data.msg);
				}
				
				
           	},
           	error: function(data) {
           		alertHttpError();
           	}
           });
		   



            return false;
        });
		
		

		//监听单元格编辑
		table.on('edit(currentTableFilter)', function(obj) {
			var value = obj.value //得到修改后的值
				,
				data = obj.data //得到所在行所有键值
				,
				field = obj.field; //得到字段

			var datas = "{\""+ field + "\":\""+ value+"\",\"id\":\""+data.id+"\"}";

			$.ajax({
				url: baseurl + "task/update",
				data: JSON.parse(JSON.stringify(datas)),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "1") {
						layer.msg('修改成功', function() {
							// obj.del();
							// layer.close(index);
							location.reload(1);
						});
					} else {
						layer.alert(data.msg);
					}
				},
				error: function(data) {
					alertHttpError();
				}
			});



		});



		table.on('tool(currentTableFilter)', function(obj) {
			var data = obj.data;
			if (obj.event === 'edit') {
				layer.confirm('直接点击你要编辑的字段即可实现编辑保存');
				return false;
			}else if (obj.event === 'delete') {
				// 执行删除用户操作
				layer.confirm('真的要删除这个任务吗？', function(index) {
					var datas = {
						"id": data.id
					};

					$.ajax({
						url: baseurl + "task/delete?id="+data.id,
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('删除成功', function() {
									obj.del();
									layer.close(index);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			}



		});




	});
};






// 添加任务
function addTask(){
	
	layui.use(['form',"upload","laydate"], function() {
		var form = layui.form,
			layer = layui.layer,
			upload = layui.upload,
			laydate = layui.laydate,
			$ = layui.$;
			
			//日期
			laydate.render({
				type:'datetime',
			    elem: '#date'
			});
			
		
	
		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认添加吗???", {
				title: '确认添加'
			}, function() {
				
					var datas = {
						  "address": data.address,
						   "content": data.content,
						   "name": data.name,
						   "startTime": data.date,
						   "type": data.type,
					};
					
					$.ajax({
						url: baseurl + "task/save",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('添加成功', function() {
									// 关闭弹出层
									layer.close(index);
					
									var iframeIndex = parent.layer
										.getFrameIndex(window.name);
									parent.layer.close(iframeIndex);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});
					
				
			});
	
			return false;
		});
	
	});
	
}







// 添加
function add() {




	layui.use(['form',"upload","laydate"], function() {
		var form = layui.form,
			layer = layui.layer,
			upload = layui.upload,
			laydate = layui.laydate,
			$ = layui.$;
			
			//日期
			laydate.render({
				type:'datetime',
			    elem: '#date'
			});
			
			
			var datas = {};
			// 异步加载任务信息
			$.ajax({
				url: baseurl + "task/list",
				data: JSON.stringify(datas),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "1") {
						var list = data.data;
			
						for (var i = 0; i < list.length; i++) {
							var option = document.createElement(
								"option"); // 创建添加option属性
							option.setAttribute("value", list[i].id); // 给option的value添加值
							option.innerText = list[i].name; // 打印option对应的纯文本 
							task.appendChild(option); //给select添加option子标签
							form.render("select"); // 刷性select，显示出数据
						}
			
			
			
					} else {
						layer.alert(data.msg);
					}
				},
				error: function(data) {
					layer.alert(JSON.stringify(data), {
						title: data
					});
				}
			});
			
			
			
			var datas = {};
			// 异步加载用户信息
			$.ajax({
				url: baseurl + "user/list",
				data: JSON.stringify(datas),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "1") {
						var list = data.data;
			
						for (var i = 0; i < list.length; i++) {
							var option = document.createElement(
								"option"); // 创建添加option属性
							option.setAttribute("value", list[i].id); // 给option的value添加值
							option.innerText = list[i].name; // 打印option对应的纯文本 
							user.appendChild(option); //给select添加option子标签
							form.render("select"); // 刷性select，显示出数据
						}
			
			
			
					} else {
						layer.alert(data.msg);
					}
				},
				error: function(data) {
					layer.alert(JSON.stringify(data), {
						title: data
					});
				}
			});
			
			
			var datas = {};
			// 异步加载打卡信息
			$.ajax({
				url: baseurl + "signIn/listSignIn",
				data: JSON.stringify(datas),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "1") {
						var list = data.data;
			
						for (var i = 0; i < list.length; i++) {
							var option = document.createElement(
								"option"); // 创建添加option属性
							option.setAttribute("value", list[i].id); // 给option的value添加值
							option.innerText = list[i].sid; // 打印option对应的纯文本 
							signIn.appendChild(option); //给select添加option子标签
							form.render("select"); // 刷性select，显示出数据
						}
			
			
			
					} else {
						layer.alert(data.msg);
					}
				},
				error: function(data) {
					layer.alert(JSON.stringify(data), {
						title: data
					});
				}
			});
			
			
			


		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认添加吗???", {
				title: '确认添加'
			}, function() {
				
					var datas = {
						  "sid": data.signIn,
						  "state": "0",
						  "tid": data.task,
						  "uid": data.user,
					};
					
					$.ajax({
						url: baseurl + "task/dispatcherTask",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('添加成功', function() {
									// 关闭弹出层
									layer.close(index);
					
									var iframeIndex = parent.layer
										.getFrameIndex(window.name);
									parent.layer.close(iframeIndex);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});
					
				
			});

			return false;
		});

	});

}


function GetQueryValue(queryName) {
    var query = decodeURI(window.location.search.substring(1));
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == queryName) { return pair[1]; }
    }
    return null;
}


// 设置职位
function setPosition() {




	layui.use(['form',"upload"], function() {
		var form = layui.form,
			layer = layui.layer,
			upload = layui.upload,
			$ = layui.$;
			
			
			// 异步加载用户职位信息
			var datas = {};
			// 异步加载折扣信息
			$.ajax({
				url: baseurl + "user/getUserByid?userid="+GetQueryValue("userid"),
				data: JSON.stringify(datas),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "1") {
						
						$("#showTel").val(data.data.tel);
						$("#showPosition").val(data.data.profession.position);
						$("#showDes").val(data.data.profession.des);
					} else {
						layer.alert(data.msg);
					}
				},
				error: function(data) {
					alertHttpError();
				}
			});
			
			
			


		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认修改吗???", {
				title: '确认修改'
			}, function() {
				
					var datas = {
						        "tel":data.tel,
								 "profession": {
								    "des": data.des,
								    "position": data.position,
								  },
					};
					
					$.ajax({
						url: baseurl + "user/setPositionByTel",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('操作成功', function() {
									// 关闭弹出层
									layer.close(index);
					
									var iframeIndex = parent.layer
										.getFrameIndex(window.name);
									parent.layer.close(iframeIndex);
									// 刷新页面
									location.reload(1);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});
					
				
			});

			return false;
		});

	});

}
