// 用户管理
function salaryLendManage() {

	layui.use(['form', 'table'], function() {
		var $ = layui.jquery,
			form = layui.form,
			table = layui.table;
		var datas = {
			"token": window.localStorage.getItem("token"),
			"userid": window.localStorage.getItem("userid"),
		};

		$.ajax({
			url: baseurl + "salaryLendLend/list",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "1") {
					var d = data.data;
					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'id',
									width: 80,
									title: 'ID'
								},
								{
									field: 'name',
									width: 100,
									title: '用户名',
									align: "center",
									templet: function(data) {
										return data.user.name
									}
								},
								{
									field: 'tel',
									width: 150,
									title: '电话',
									align: "center",
									templet: function(data) {
										return data.user.tel
									}
								},
								{
									field: 'num',
									width: 120,
									title: '借资金额',
									align: "center"
								},
								{
									field: 'reson',
									width: 150,
									title: '申请理由',
									align: "center"
								},
								{
									field: 'state',
									width: 120,
									title: '申请状态',
									align: "center",
									templet: function(data) {
										if (data.state == "0") {
											tmp = "申请待审批";
											return "<span style='color:#00aaff'>" +
												tmp + "</span>";
										}
										if (data.state == "1") {
											tmp = "审核通过";
											return "<span style='color:#55ff7f'>" +
												tmp + "</span>";
										}
										if (data.state == "2") {
											tmp = "审核拒绝";
											return "<span style='color:#ff0000'>" +
												tmp + "</span>";
										}
									}

								},
								{
									title: '操作',
									minWidth: 300,
									toolbar: '#currentTableBar',
									align: "center"
								}
							]
						],
						limits: [5, 10, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});


				} else {
					layer.alert(data.msg);
				}
			},
			error: function(data) {
				alertHttpError();
			}
		});




		/**
		 * toolbar监听事件
		 */
		table.on('toolbar(currentTableFilter)', function(obj) {
			if (obj.event === 'add') { // 监听添加操作
				var index = layer.open({
					title: '添加',
					type: 2,
					shade: 0.2,
					maxmin: true,
					shadeClose: true,
					area: ['100%', '100%'],
					content: 'add.html',
				});
				$(window).on("resize", function() {
					layer.full(index);
				});
			}

		});








		table.on('tool(currentTableFilter)', function(obj) {
			var data = obj.data;
			if (obj.event === 'edit') {
				layer.confirm('直接点击你要编辑的字段即可实现编辑保存');
				return false;
			} else if (obj.event === 'pass') {
				// 执行删除用户操作
				layer.confirm('确定通过审核吗？', function(index) {
					var datas = {
						"id": data.id,
						"state": "1",
					};

					$.ajax({
						url: baseurl + "salaryLendLend/update",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('操作成功', function() {
									// 刷新页面
									location.reload(1);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			} else if (obj.event === 'refuse') {
				// 执行删除用户操作
				layer.confirm('确定拒绝此申请吗？', function(index) {
					var datas = {
						"id": data.id,
						"state": "2",
					};

					$.ajax({
						url: baseurl + "salaryLendLend/update",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('操作成功', function() {
									// 刷新页面
									location.reload(1);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			} else if (obj.event === 'delete') {
				// 执行删除操作
				layer.confirm('真的要删除吗？', function(index) {
					var datas = {
						"id": data.id
					};

					$.ajax({
						url: baseurl + "salaryLendLend/delete?id=" + data.id,
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('删除成功', function() {
									obj.del();
									layer.close(index);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			}

		});

	});
}
