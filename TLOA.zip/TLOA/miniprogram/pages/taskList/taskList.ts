// pages/taskList/taskList.ts
import { request } from "../../request/request";


Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.getTask();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
    // 我的任务信息
    getTask() {
      // var id = wx.getStorageSync("userinfo").id;
      var uid = wx.getStorageSync("userinfo").id;
      // var id = 1;
      request({
        url: "/task/listByUid?userid=" + uid, data: {
          "pvender": ""
        }
      })
        .then(result => {
          this.setData({
            taskList: result.data,
          });
  
        })
    },

    toTaskDetail(e){
      console.log(e);
      var id = e.currentTarget.dataset.id;
      wx.navigateTo({
        url:"/pages/taskDetail/taskDetail?id="+id
      });
    }

})