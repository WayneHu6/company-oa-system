// pages/myTemperature/myTemperature.js
var app = getApp();

const baseurl = "http://192.168.31.109:9087/";
import { request } from "../../request/request";

Page({

  /**
   * 页面的初始数据
   */
  data: {
    temperatureList: [],
    snum: "",
    vbodypart: ['请选择所属任务'],// 所属任务
    vbodypartIndex: 0,
    vbodypartIndexs: [-1],
    vbodypartStr: "",

    remark: ['请选择打卡类型',"上班打卡","下班打卡"],// 打卡类型
    remarkIndex: 0,
    remarkStr: "",

    tid: 0,
    sid: 0,
    taskList: [],
    images:[],

  },

  // 下拉选择改变事件-任务选择
  bindsexPickerChange: function (e) {
    console.log(e);
    console.log('bindsexPicker发送选择改变，携带值为', e.detail.value)
    var index = e.detail.value;
    this.setData({
      vbodypartIndex: e.detail.value,
      vbodypartStr: this.data.vbodypart[e.detail.value],
      tid: this.data.vbodypartIndexs[e.detail.value],
      sid: this.data.taskList[index - 1].signIn.id
    })
  },
  // 下拉选择改变事件-打卡类型
  bindsexPickerChange_remark: function (e) {
    console.log(e);
    console.log('bindsexPicker发送选择改变，携带值为', e.detail.value)
    var index = e.detail.value;
    this.setData({
      remarkIndex: e.detail.value,
      remarkStr: this.data.remark[e.detail.value],
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getTask();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getTask();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  // 我的任务信息
  getTask() {
    // var id = wx.getStorageSync("userinfo").id;
    var uid = wx.getStorageSync("userinfo").id;
    // var id = 1;
    request({
      url: "/task/listByUid?userid=" + uid, data: {
        "pvender": ""
      }
    })
      .then(result => {
        this.setData({
          taskList: result.data,
        });

        var list = this.data.vbodypart;
        var listIds = [];
        for (let index = 0; index < this.data.taskList.length; index++) {
          list[index + 1] = this.data.taskList[index].name;
          listIds[index + 1] = this.data.taskList[index].id;
        }

        this.setData({
          vbodypart: list,
          vbodypartIndexs: listIds
        });


      })
  },
  
  toChooseImage(){
    var that = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: [ 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片，只有一张图片获取下标为0
        var tempFilePaths = res.tempFilePaths[0];
        that.setData({
          imgUrl: tempFilePaths,
          actionSheetHidden: !that.data.actionSheetHidden
        });
        wx.uploadFile({
          filePath: tempFilePaths,
          name: 'file',
          dataType: "json",
          url: baseurl+'common/upload',
          success: function (res) {
            var datas = JSON.parse(res.data);
            if(datas.code==1){
              // 文件上传成功 更新ui
            // var len = that.data.images.length;
            that.data.images[0] = baseurl+"common/download?name="+datas.data;
            that.setData({
              images: that.data.images
            })

            }



          },
          fail: function () {
            console.log(res);

            wx.showToast({
              title: '上传失败',
              icon: 'error',
              duration: 2000
            })
          }

        })

      }
    });
  },




  // 签到按钮点击事件
  submit() {
    if (this.data.sid == 0) {
      wx.showModal({
        title: "请先选择对应的任务"
      });
      return;
    }
    if (this.data.remarkStr.length<1 || this.data.remarkStr=="请选择打卡类型") {
      wx.showModal({
        title: "请选择打卡类型"
      });
      return;
    }
    if (this.data.images.length<1) {
      wx.showModal({
        title: "请拍照签到照片"
      });
      return;
    }

    // var id = wx.getStorageSync("userinfo").id;
    var id = 1;
    request({
      url: "/signIn/save", data: {
        "img": this.data.images[0],
        "remark": "上班打卡",
        "sid": this.data.sid,
        "uid": id,
      }
    })
      .then(result => {
        if (result.code == 0) {
          // 失败 解析msg消息
          wx.showToast({
            icon: "error",
            title: result.msg
          })
        } else {
          // 成功 解析data数据
          wx.showToast({
            icon: "success",
            title: result.data
          })
        }

      })
  },

})