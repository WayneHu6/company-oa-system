// pages/taskList/taskList.ts
import { request } from "../../request/request";


Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.getTask();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  // 我的任务信息
  getTask() {
    request({
      url: "/tool/list", data: {
        "num": 1,
      }
    })
      .then(result => {
        if (result.code == 0) {
          // 失败 解析msg消息
          wx.showToast({
            icon: "error",
            title: result.msg
          })
        } else {
          this.setData({
            toolList: result.data
          });
        }

      })
  },

  // 跳转到详细页面
  toToolDetail(e){
    console.log(e);
    var id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url:"/pages/toolDetail/toolDetail?id="+id
    });
  },

  // 添加到工具箱
  addWorkBox(e) {
    console.log(e);
    var tmid = e.currentTarget.dataset.id;
    // var id = wx.getStorageSync("userinfo").id;
    var uid = wx.getStorageSync("userinfo").id;
    // var uid = 1;
    request({
      url: "/workBox/save", data: {
        "num": 1,
        "tid": 1,
        "tmid": tmid,
        "type": "0",
        "uid": uid,
      }
    })
      .then(result => {
        if (result.code == 0) {
          // 失败 解析msg消息
          wx.showToast({
            icon: "error",
            title: result.msg
          })
        } else {
          var that = this;
          // 成功 解析data数据
          wx.showToast({
            icon: "success",
            title: result.data,
          });

          setTimeout(() => {
            console.log("延迟执行");
            // 完成后更新
            that.getTask();
          }, 2000);

        }

      })

  },




})