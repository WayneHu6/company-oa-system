// pages/myTemperature/myTemperature.js
var app = getApp();
import { request } from "../../request/request";

Page({

  /**
   * 页面的初始数据
   */
  data: {
    temperatureList:[],
    snum: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getVannice();   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

      // 获取我的疫苗接种信息
      getVannice(){
        // var id = wx.getStorageSync("userinfo").id;
        var uid = wx.getStorageSync("userinfo").id;
        // var id = 1;
        request({url:"/vaccine/listByUid?userid="+uid,data:{
          "pvender":""
        }})
        .then(result=>{
          this.setData({
            vanniceList:result.data
          })
        })
      },

})