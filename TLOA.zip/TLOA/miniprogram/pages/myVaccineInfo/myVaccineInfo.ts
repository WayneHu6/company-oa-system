// pages/myTemperature/myTemperature.js
import { request } from "../../request/request";


Page({

  /**
   * 页面的初始数据
   */
  data: {
    vbodypart: ['请选择接种部位', '左上臂', '右上臂'],// 接种部位
    vbodypartIndex:0,
    vbodypartStr:"",
    timeDivision: "请选择",//时分秒，根据需要选择
    pvender: "",   // 生产厂家
    vdate: "请选择接种日期",     // 接种日期
    vdoctor: "",   // 接种医生
    vendDate: "请选择有效日期",  // 疫苗有效期
    vnumber: "",   // 疫苗批号
    vunit: "",     // 接种单位
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  bindKeyInputName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  bindsexPickerChange: function (e) {
    console.log(e);
    
    console.log('bindsexPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      vbodypartIndex: e.detail.value,
      vbodypartStr:this.data.vbodypart[e.detail.value]
    })
  },
  bindKeyAddress: function (e) {
    this.setData({
      address: e.detail.value
    })
  },
  bindeduPickerChange: function (e) {
    console.log('bindeduPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      eduindex: e.detail.value
    })
  },
  bindtypePickerChange: function (e) {
    console.log('bindtypePicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      typeindex: e.detail.value
    })
  },
  
  bindKeyInputNum_vunit: function (e) {
    this.setData({
      vunit: e.detail.value
    })
  },

  bindKeyInputNum_vdoctor: function (e) {
    this.setData({
      vdoctor: e.detail.value
    })
  },

  bindKeyInputNum_pvender: function (e) {
    this.setData({
      pvender: e.detail.value
    })
  },

  bindKeyInputNum_vnumber: function (e) {
    this.setData({
      vnumber: e.detail.value
    })
  },

  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
    // 改变接种时间
    selectDateSecondChange_vdate(e) {
      console.log(e);
      this.setData({
        vdate: e.detail.value
      })
    },
    // 改变有效时间
    selectDateSecondChange_vendDate(e) {
      console.log(e);
      this.setData({
        vendDate: e.detail.value
      })
    },

    // 添加疫苗接种信息的方法
addVaccineInfo(){
  request({url:"/vaccine/save",data:{
    "userid":wx.getStorageSync("userinfo").id,
    "vunit":this.data.vunit,
    "pvender":this.data.pvender,
    "vnumber":this.data.vnumber,
    "vendDate":this.data.vendDate,
    "vbodypart":this.data.vbodypartStr,
    "vdoctor":this.data.vdoctor,
    "vdate":this.data.vdate,
  }})
  .then(result=>{
    wx.showModal({
      title:result.data
    });
  })
},

})