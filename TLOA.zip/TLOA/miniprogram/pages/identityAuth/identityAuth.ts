// pages/myTemperature/myTemperature.js
var app = getApp();

const baseurl = "http://192.168.31.109:9087/";
import { request } from "../../request/request";

Page({

  /**
   * 页面的初始数据
   */
  data: {

    images:[],
    images2:[],
    name:"",
    idCard:"",

  },

  // 下拉选择改变事件-任务选择
  bindsexPickerChange: function (e) {
    console.log(e);
    console.log('bindsexPicker发送选择改变，携带值为', e.detail.value)
    var index = e.detail.value;
    this.setData({
      vbodypartIndex: e.detail.value,
      vbodypartStr: this.data.vbodypart[e.detail.value],
      tid: this.data.vbodypartIndexs[e.detail.value],
      sid: this.data.taskList[index - 1].signIn.id
    })
  },
  // 下拉选择改变事件-打卡类型
  bindsexPickerChange_remark: function (e) {
    console.log(e);
    console.log('bindsexPicker发送选择改变，携带值为', e.detail.value)
    var index = e.detail.value;
    this.setData({
      remarkIndex: e.detail.value,
      remarkStr: this.data.remark[e.detail.value],
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getTask();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getTask();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  nameInput(e){
    this.setData({
      name:e.detail.value
    });
  },
  idcardInut(e){
    this.setData({
      idCard:e.detail.value
    });
  },


  
  toChooseImage(){
    var that = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片，只有一张图片获取下标为0
        var tempFilePaths = res.tempFilePaths[0];
        that.setData({
          imgUrl: tempFilePaths,
          actionSheetHidden: !that.data.actionSheetHidden
        });
        wx.uploadFile({
          filePath: tempFilePaths,
          name: 'file',
          dataType: "json",
          url: baseurl+'common/upload',
          success: function (res) {
            var datas = JSON.parse(res.data);
            if(datas.code==1){
              // 文件上传成功 更新ui
            // var len = that.data.images.length;
            that.data.images[0] = baseurl+"common/download?name="+datas.data;
            that.setData({
              images: that.data.images
            })

            }



          },
          fail: function () {
            console.log(res);

            wx.showToast({
              title: '上传失败',
              icon: 'error',
              duration: 2000
            })
          }

        })

      }
    });
  },


  toChooseImage2(){
    var that = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片，只有一张图片获取下标为0
        var tempFilePaths = res.tempFilePaths[0];
        that.setData({
          imgUrl: tempFilePaths,
          actionSheetHidden: !that.data.actionSheetHidden
        });
        wx.uploadFile({
          filePath: tempFilePaths,
          name: 'file',
          dataType: "json",
          url: baseurl+'common/upload',
          success: function (res) {
            var datas = JSON.parse(res.data);
            if(datas.code==1){
              // 文件上传成功 更新ui
            // var len = that.data.images.length;
            that.data.images2[0] = baseurl+"common/download?name="+datas.data;
            that.setData({
              images2: that.data.images2
            })

            }



          },
          fail: function () {
            console.log(res);

            wx.showToast({
              title: '上传失败',
              icon: 'error',
              duration: 2000
            })
          }

        })

      }
    });
  },







  // 按钮点击事件
  submit() {
    if (this.data.name.length<2) {
      wx.showModal({
        title: "请输入正确姓名"
      });
      return;
    }
    if (this.data.idCard.length<15) {
      wx.showModal({
        title: "请输入正确身份证号码"
      });
      return;
    }
    if (this.data.images.length<1) {
      wx.showModal({
        title: "请拍照身份证正面照片"
      });
      return;
    }
    if (this.data.images2.length<1) {
      wx.showModal({
        title: "请拍照身份证反面照片"
      });
      return;
    }

    
    // var uid = 1;
    var uid = wx.getStorageSync("userinfo").id;
    request({
      url: "/user/update", data: {
  "id": uid,
  "idCard": this.data.idCard,
  "idcardImg1": this.data.images[0],
  "idcardImg2": this.data.images2[0],
  "name": this.data.name,
      }
    })
      .then(result => {
        if (result.code == 0) {
          // 失败 解析msg消息
          wx.showToast({
            icon: "error",
            title: result.msg
          })
        } else {
          // 成功 解析data数据
          wx.showToast({
            icon: "success",
            title: result.data
          })
        }

      })
  },

})