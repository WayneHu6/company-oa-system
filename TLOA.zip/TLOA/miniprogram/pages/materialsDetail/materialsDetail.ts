// pages/taskList/taskList.ts
import { request } from "../../request/request";


Page({

  /**
   * 页面的初始数据
   */
  data: {
    toolId:"",
    vbodypart: ['请选择所属任务'],// 所属任务
    vbodypartIndex: 0,
    vbodypartIndexs: [-1],
    vbodypartStr: "",
    sid:0,
    inputNum:0

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(option) {
    this.setData({
      toolId:option.id
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.getTask();
    this.getTool(this.data.toolId);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  inputNum(e){
    this.setData({
      inputNum: e.detail.value
    });
  },

    // 下拉选择改变事件-任务选择
    bindsexPickerChange: function (e) {
      console.log(e);
      console.log('bindsexPicker发送选择改变，携带值为', e.detail.value)
      var index = e.detail.value;
      this.setData({
        vbodypartIndex: e.detail.value,
        vbodypartStr: this.data.vbodypart[e.detail.value],
        tid: this.data.vbodypartIndexs[e.detail.value],
        sid: this.data.taskList[index - 1].signIn.id
      })
    },


  // 获取详细工具信息
  getTool(id) {
    request({
      url: "/materials/listById?id="+id, data: {
        "num": 1,
      }
    })
      .then(result => {
        if (result.code == 0) {
          // 失败 解析msg消息
          wx.showToast({
            icon: "error",
            title: result.msg
          })
        } else {
          this.setData({
            toolList: result.data
          });
        }

      })
  },
    // 我的任务信息
    getTask() {
      // var id = wx.getStorageSync("userinfo").id;
      // var id = 1;
      var uid = wx.getStorageSync("userinfo").id;
      request({
        url: "/task/listByUid?userid=" + uid, data: {
          "pvender": ""
        }
      })
        .then(result => {
          this.setData({
            taskList: result.data,
          });
  
          var list = this.data.vbodypart;
          var listIds = [];
          for (let index = 0; index < this.data.taskList.length; index++) {
            list[index + 1] = this.data.taskList[index].name;
            listIds[index + 1] = this.data.taskList[index].id;
          }
  
          this.setData({
            vbodypart: list,
            vbodypartIndexs: listIds
          });
  
  
        })
    },



  // 添加到工具箱
  addWorkBox(e) {
    console.log(e);
    if (this.data.sid == 0) {
      wx.showModal({
        title: "请先选择对应的任务"
      });
      return;
    }
    if (this.data.inputNum<1) {
      wx.showModal({
        title: "请输入正确的数量"
      });
      return;
    }
    
    // var uid = wx.getStorageSync("userinfo").id;
    var uid = wx.getStorageSync("userinfo").id;
    // var uid = 1;
    request({
      url: "/workBox/save", data: {
        "num": this.data.inputNum,
        "tid": this.data.sid,
        "tmid": this.data.toolId,
        "type": "1",
        "uid": uid,
      }
    })
      .then(result => {
        if (result.code == 0) {
          // 失败 解析msg消息
          wx.showToast({
            icon: "error",
            title: result.msg
          })
        } else {
          var that = this;
          // 成功 解析data数据
          wx.showToast({
            icon: "success",
            title: result.data,
          });

          setTimeout(() => {
            console.log("延迟执行");
            // 完成后更新
            that.getTask();
          }, 2000);

        }

      })

  },




})