
import { request } from "../../request/request";

Page({

  /**
   * 页面的初始数据
   */
  data: {
    //日期 时间
    todayDate: '',
    todayTime: '',
    get_date: '',
    jobCard:[],
  },

  getTime: function () {
    var date = new Date();
    var minute = date.getMinutes() >= 10 ? date.getMinutes() : ('0' + date.getMinutes());
    var hour = date.getHours() >= 10 ? date.getHours() : ('0' + date.getHours());
    var now = date.getDate() >= 10 ? date.getDate() : ('0' + date.getDate());
    var todayDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + now;
    var todayTime = hour + ':' + minute;
    this.setData({
      todayDate: todayDate,
      todayTime: todayTime
    })
  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getTime();
    this.getJobCard();

  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 获取我的出入证
  getJobCard() {
    // var id = wx.getStorageSync("userinfo").id;
    var id = 1;
    request({ url: "/user/getUserByid?userid="+id, data: { "userid": 1 } })
      .then(result => {
        this.setData({
          jobCard:result.data
        });
      })
  },






})