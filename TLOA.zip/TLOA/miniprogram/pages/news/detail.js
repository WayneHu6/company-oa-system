//index.js
import {
  request
} from "../../request/request";

//获取应用实例
var app = getApp();
var wxb = require('../../utils/wxb.js');
Page({
  data: {
    color: '',
  },

  onLoad: function (option) {
    console.log(option);
    wxb.that = this;
    wxb.style();

    this.getNotice(option.id);

  },
  // 获取所有通知公告信息
  getNotice(id) {
    request({
        url: "/notice/listById?id="+id,
        data: {
          "userid": 1
        }
      })
      .then(result => {
        this.setData({
          notice: result.data
        });
      })
  },

})