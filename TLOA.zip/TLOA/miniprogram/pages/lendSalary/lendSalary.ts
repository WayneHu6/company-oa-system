//index.js
//获取应用实例
var app = getApp();
var wxb = require('../../utils/wxb.js');
import { request } from "../../request/request";

Page({
  data: {
    color: '',
  },

  onLoad: function () {
    wxb.that = this;
    wxb.style();

  },
 
  fromSubmit: function (e) {
    console.log('fromSubmit');
    var params = e.detail.value;
    console.log(e);

          // var uid = wx.getStorageSync("userinfo").id;
          // var uid = 1;
          var uid = wx.getStorageSync("userinfo").id;
          request({ url: "/salaryLendLend/save", data: { 
            "num": params.num,
            "reson": params.reson,
            "uid": uid,
           } })
            .then(result => {
              if (result.code == 0) {
                // 失败 解析msg消息
                wx.showToast({
                  icon: "error",
                  title: result.msg
                })
              } else {
                // 成功 解析data数据
                wx.showToast({
                  icon: "success",
                  title: result.data
                })
              }

            })


  },



})
