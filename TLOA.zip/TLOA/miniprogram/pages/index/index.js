//index.js
import {
  request
} from "../../request/request";


Page({
  data: {
    color: '',
    datas: [],
    // service_tel: "0551-12345678", 服务电话
    // complaint_tel: "0551-12345678" 投诉电话
    setting: [],
  },

  onShow: function () {
    this.getBanner();
    this.getNotice();
    this.getCompany();
  },

  onLoad: function () {
    // wxb.that = this;
    // wxb.style();
    // this.getHome();
    this.getBanner();
    this.getNotice();
    this.getCompany();
  },



  // calling: function () {
  //   wx.makePhoneCall({
  //     phoneNumber: wxb.that.data.setting.service_tel, //此号码并非真实电话号码，仅用于测试
  //     success: function () {
  //       console.log("拨打电话成功！")
  //     },
  //     fail: function () {
  //       console.log("拨打电话失败！")
  //     }
  //   })
  // },

  // jjfa: function(){
  //   wx.navigateTo({
  //     url: '/pages/case/index',
  //   })
  // },

  // cpzx: function(){
  //   wx.navigateTo({
  //     url: '/pages/product/index',
  //   })
  // },

  // 获取所有轮播图
  getBanner() {
    request({
        url: "/banner/list",
        data: {
          "userid": 1
        }
      })
      .then(result => {
        this.setData({
          bannerList: result.data
        });
      })
  },
  // 获取所有通知公告信息
  getNotice() {
    request({
        url: "/notice/list",
        data: {
          "userid": 1
        }
      })
      .then(result => {
        this.setData({
          noticeList: result.data
        });
      })
  },

    // 获取公司信息信息
    getCompany() {
      request({
          url: "/company/list",
          data: {
            "userid": 1
          }
        })
        .then(result => {
          this.setData({
            companyList: result.data
          });
        })
    },
  


  qydt: function () {
    wx.navigateTo({
      url: '/pages/news/index',
    })
  },

  //转发
  // onShareAppMessage: function (res) {
  //   wxb.that = this;   //正确打开海天应用的方式
  //   wxb.globalData = app.globalData; //正确打开海天应用的方式
  //   return {
  //     title: '企业官网',
  //     path: '/pages/index/index',
  //     success: function (res) {
  //       // 转发成功
  //       wx.showToast({
  //         title: '已转发',
  //       })
  //     },
  //     fail: function (res) {
  //       // 转发失败
  //       wx.showToast({
  //         title: '转发失败',
  //       })
  //     }
  //   }
  // }
})