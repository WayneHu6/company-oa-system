// pages/taskDetail/taskDetail.ts
import { request } from "../../request/request";


Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(option) {
    this.getTask(option.id);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  // 通过id获取任务信息
  getTask(id) {
    // var uid = wx.getStorageSync("userinfo").id;
    var uid = wx.getStorageSync("userinfo").id;
    // var uid = 1;
    request({
      url: "/task/listByidAndUid?id=" + id + "&userid=" + uid, data: {
        "pvender": ""
      }
    })
      .then(result => {
        this.setData({
          taskList: result.data,
        });

      })
  },


  // 确认任务信息
  submit() {
    // var uid = wx.getStorageSync("userinfo").id;
    var uid = wx.getStorageSync("userinfo").id;
    // var uid = 1;
    request({
      url: "/task/confirmTask?tsid=" + this.data.taskList.tus.tsid, data: {
        "pvender": ""
      }
    })
      .then(result => {
        if (result.code == 0) {
          // 失败 解析msg消息
          wx.showToast({
            icon: "error",
            title: result.msg
          })
        } else {
          // 成功 解析data数据
          wx.showToast({
            icon: "success",
            title: result.data
          })
        }

      })
  },



})