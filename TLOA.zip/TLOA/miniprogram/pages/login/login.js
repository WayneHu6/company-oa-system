// let md5 = require("../MD5.js");
// let checkNetWork = require("../CheckNetWork.js");
import {request} from "../../request/request";


let app = getApp();
Page({
  data: {
    focus: false,
    btnDisabled: true,
    userLogin: {
      loginName: '',
      password: ''
    }

  },
  userInput: function(e) {  //手机号输入
    let inputValue = e.detail.value;
      this.setData({
        'userLogin.loginName': inputValue
      });
  },
  pswInput: function(e) {   //密码输入
    let that = this;
    let inputValue = e.detail.value;
    // let md5Psw = md5.hexMD5(inputValue);
    let md5Psw = inputValue;
    let length = e.detail.value.length;
    if(length >= 6 && length <= 20){ 
      that.setData({
        'userLogin.password': md5Psw,
        btnDisabled: false
      })
    } 
  },
  forgetPsw(){
    wx.showModal({
      title:"忘记密码请联系管理员"
    })
  },
  bindButtonTap: function() { //登陆按钮

      let params = this.data.userLogin;
      console.log(params);

      request({ url: "/user/login", data: { 
        "tel": params.loginName,
        "psd": params.password,
       } })
      .then(result => {
        if(result.code==1){
          wx.showToast({  //显示密码错误信息
            title: '登录成功',
            icon: 'error',
            duration: 2500
          });
          wx.setStorageSync("userinfo",result.data);
          wx.reLaunch({
            url:"/pages/index/index"
          });
        }else{
          wx.showToast({  //显示密码错误信息
            title: result.msg,
            icon: 'error',
            duration: 2500
          });
        }
      })

    
  },
  onLoad: function () {
    try {
        wx.setStorageSync('token', '')
    } catch (e) {    
    }
  }
})
