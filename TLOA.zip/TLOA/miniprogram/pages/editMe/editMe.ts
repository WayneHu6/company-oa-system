// miniprogram/pages/mine/myInfo/showmyinfo/showmyinfo.js
var app = getApp();
import { request } from "../../request/request";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sexarray: [' ', '男', '女'],//性别
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getMyInfo();
  },
  bindKeyInputName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },

  bindsexPickerChange: function (e) {
    console.log('bindsexPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      sexindex: e.detail.value,
      sex:e.detail.value,
    })
  },
  bindeduPickerChange: function (e) {
    console.log('bindeduPicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      eduindex: e.detail.value
    })
  },
  bindtypePickerChange: function (e) {
    console.log('bindtypePicker发送选择改变，携带值为', e.detail.value)
    this.setData({
      typeindex: e.detail.value
    })
  },
  bindKeyInputNum: function (e) {
    this.setData({
      snumber: e.detail.value
    })
  },
  bindKeyAddress: function (e) {
    this.setData({
      addrss: e.detail.value
    })
  },
  bindKeyFaculty: function (e) {
    this.setData({
      college: e.detail.value
    })
  },
  bindKeyMajor: function (e) {
    this.setData({
      major: e.detail.value
    })
  },
  bindKeyClass: function (e) {
    this.setData({
      gclass: e.detail.value
    })
  },
  bindKeyRoomnum: function (e) {
    this.setData({
      idcard: e.detail.value
    })
  },
  bindKeyPhonenum: function (e) {
    this.setData({
      tel: e.detail.value
    })
  },
  gotochangeinfo: function () {
    request({url:"/user/update",data:{
      address: this.data.addrss,
      id: this.data.id,
      idCard: this.data.idcard,
      sex: this.data.sex,
      tel: this.data.tel,
    }})
    .then(result=>{
      if (result.code == 0) {
        // 失败 解析msg消息
        wx.showToast({
          icon: "error",
          title: result.msg
        })
      } else {
        // 成功 解析data数据
        wx.showToast({
          icon: "success",
          title: result.data
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getMyInfo();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  },


  getMyInfo(){
    var uid = wx.getStorageSync("userinfo").id;
    // var uid = 1;
    request({url:"/user/getUserByid?userid="+uid,data:{
      "userid":1,
    }})
    .then(result=>{
      this.setData({
        account: result.data.account,
        address: result.data.address,
        age: result.data.age,
        college: result.data.college,
        gclass: result.data.gclass,
        grade: result.data.grade,
        header: result.data.header,
        icon: result.data.icon,
        id: result.data.id,
        idcard: result.data.idCard,
        major: result.data.major,
        name: result.data.name,
        psd: result.data.psd,
        sendDatetime: result.data.sendDatetime,
        sex: result.data.sex,
        snumber: result.data.snumber,
        tel: result.data.tel,
        updateDatetime: result.data.updateDatetime,
      });
    })
  },


})