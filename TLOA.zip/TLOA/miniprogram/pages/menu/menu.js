// pages/menu/menu.js



Page({

  /**
   * 页面的初始数据
   */
  data: {
    routers: [
      {
        name: '打卡签到',
        url: '/pages/signIn/signIn',
        icon: '/images/circle.png'
      },
      {
        name: '工作任务',
        url: '/pages/taskList/taskList',
        icon: '/images/circle.png'
      },
      {
        name: '工具申领',
        url: '/pages/toolList/toolList',
        icon: '/images/circle.png'
      },
      {
        name: '耗材申领',
        url: '/pages/materialsList/materialsList',
        icon: '/images/circle.png'
      },
      {
        name: '汇报工作进度',
        url: '../device/device',
        icon: '/images/circle.png'
      },
      {
        name: '我的薪资',
        url: '/pages/mySalary/mySalary',
        icon: '/images/circle.png'
      },
      {
        name: '借资',
        url: '/pages/lendSalary/lendSalary',
        icon: '/images/circle.png'
      },
      {
        name: '我的出勤',
        url: '/pages/signInList/signInList',
        icon: '/images/circle.png'
      },
      {
        name: '请假',
        url: '/pages/leave/leave',
        icon: '/images/circle.png'
      },
      {
        name: '工具箱',
        url: '/pages/workBoxList/workBoxList',
        icon: '/images/circle.png'
      }
    ]
  }, 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})