// pages/taskList/taskList.ts
import { request } from "../../request/request";


Page({

  /**
   * 页面的初始数据
   */
  data: {
    hiddenmodalput:true,
    num:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.getWorkList();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  // 自定义弹窗取消
  cancelM:function(e){
    this.setData({
       hiddenmodalput: true,
    })
 },
  // 自定义弹窗确认
 confirmM: function (e) {
  this.materialsBack(this.data.tmid,this.data.wid,this.data.num);
},
  // 自定义弹窗输入
Num: function (e) {
  this.setData({
     num: e.detail.value
  })
},

  // 我的工具箱信息
  getWorkList() {
    var uid = wx.getStorageSync("userinfo").id;
    // var uid = 1;
    request({
      url: "/workBox/listByUid?userid="+uid, data: {
        "num": 1,
      }
    })
      .then(result => {
        if (result.code == 0) {
          // 失败 解析msg消息
          wx.showToast({
            icon: "error",
            title: result.msg
          })
        } else {
          this.setData({
            workBoxList: result.data
          });
        }

      })
  },

  // 归还工具按钮点击事件
  toToolBack(e){
    console.log(e);
    var tmid = e.currentTarget.dataset.tmid;
    var wid = e.currentTarget.dataset.wid;
    var that = this;
    wx.showModal({
      title:"请将物品归与原处,确定归还吗?",
      confirmText:"确定归还",
      success:function(res){
        if(res.confirm){
          // 点击确认
          that.toolBack(tmid,wid);
        }
        
      }
    });
  },

    // 归还材料按钮点击事件
    toMaterialsBack(e){
      this.setData({
        hiddenmodalput:false,
        tmid: e.currentTarget.dataset.tmid,
        wid: e.currentTarget.dataset.wid
      });

      // console.log(e);
      // var tmid = e.currentTarget.dataset.tmid;
      // var wid = e.currentTarget.dataset.wid;
      // var that = this;
      // wx.showModal({
      //   title:"请将物品归与原处,确定归还吗?",
      //   confirmText:"确定归还",
      //   success:function(res){
      //     if(res.confirm){
      //       // 点击确认
      //       that.materialsBack(tmid,wid);
      //     }
          
      //   }
      // });
    },

  // 归还工具
  toolBack(tmid,wid){
     // var id = wx.getStorageSync("userinfo").id;
     var uid = wx.getStorageSync("userinfo").id;
    //  var uid = 1;
     request({
       url: "/workBox/back", data: {
         "num": 1,
         "id": wid,
         "tmid": tmid,
         "type": "0",
         "uid": uid,
       }
     })
       .then(result => {
         if (result.code == 0) {
           // 失败 解析msg消息
           wx.showToast({
             icon: "error",
             title: result.msg
           })
         } else {
           var that = this;
           // 成功 解析data数据
           wx.showToast({
             icon: "success",
             title: result.data,
           });
 
           setTimeout(() => {
             console.log("延迟执行");
             // 完成后更新
             that.getWorkList();
           }, 2000);
 
         }
 
       })

  },

   // 材料余量归还
   materialsBack(tmid,wid,num){
    // var id = wx.getStorageSync("userinfo").id;
    var uid = 1;
    request({
      url: "/workBox/back", data: {
        "num": num,
        "id": wid,
        "tmid": tmid,
        "type": "1",
        "uid": uid,
      }
    })
      .then(result => {
        if (result.code == 0) {
          // 失败 解析msg消息
          wx.showToast({
            icon: "error",
            title: result.msg
          })
        } else {
          var that = this;
          // 成功 解析data数据
          wx.showToast({
            icon: "success",
            title: result.data,
          });

          setTimeout(() => {
            console.log("延迟执行");
            // 完成后更新
            that.getWorkList();
          }, 2000);

        }

      })

 },


  // 添加到工具箱
  addWorkBox(e) {
    console.log(e);
    var tmid = e.currentTarget.dataset.id;
    // var id = wx.getStorageSync("userinfo").id;
    var uid = wx.getStorageSync("userinfo").id;
    // var uid = 1;
    request({
      url: "/workBox/save", data: {
        "num": 1,
        "tid": 1,
        "tmid": tmid,
        "type": "0",
        "uid": uid,
      }
    })
      .then(result => {
        if (result.code == 0) {
          // 失败 解析msg消息
          wx.showToast({
            icon: "error",
            title: result.msg
          })
        } else {
          var that = this;
          // 成功 解析data数据
          wx.showToast({
            icon: "success",
            title: result.data,
          });

          setTimeout(() => {
            console.log("延迟执行");
            // 完成后更新
            that.getTask();
          }, 2000);

        }

      })

  },




})