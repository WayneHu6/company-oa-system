//index.js
//获取应用实例
const app = getApp()
import { request } from "../../request/request";


Page({

  /**
   * 页面的初始数据
   */
  data: {
    menu: [{
      "text": "完善个人信息",
      "img": "/images/pview.png",
      "url": "/pages/editMe/editMe"
    }, {
      "text": "身份认证",
      "img": "/images/circle.png",
      "url": "/pages/identityAuth/identityAuth"
    }, {
      "text": "我的打卡记录",
      "img": "/images/news.png",
      "url": "/pages/signInList/signInList"
    }, {
      "text": "上报疫苗信息",
      "img": "/images/set.png",
      "url": "/pages/myVaccineInfo/myVaccineInfo"
    },
    {
      "text": "查看公司信息",
      "img": "/images/set.png",
      "url": "/pages/setting/setting"
    },
    {
      "text": "我的借资信息",
      "img": "/images/set.png",
      "url": "/pages/lendSalaryList/lendSalaryList"
    },
    {
      "text": "我的请假信息",
      "img": "/images/set.png",
      "url": "/pages/leaveList/leaveList"
    },
    {
      "text": "工具箱",
      "img": "/images/set.png",
      "url": "/pages/workBoxList/workBoxList"
    },
    {
      "text": "反馈意见",
      "img": "/images/set.png",
      "url": "/pages/feedback/feedback"
    }
  ],
    userInfo: {},
    // baseUrl: app.globalData.baseUrl,
    hasUserInfo: true,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {

    this.getUserInfo();
  },

  // 退出登录
  exit(){
    wx.clearStorageSync();
    wx.redirectTo({
      url: '/pages/login/login',
    })
  },

    // 我的任务信息
    getUserInfo() {
      // var uid = 1;
      var uid = wx.getStorageSync("userinfo").id;
      request({
        url: "/user/getUserByid?userid="+uid, data: {
          "num": 1,
        }
      })
        .then(result => {
          if (result.code == 0) {
            // 失败 解析msg消息
            wx.showToast({
              icon: "error",
              title: result.msg
            })
          } else {
            this.setData({
              userInfo: result.data
            });
          }
  
        })
    },


  // getUserInfo: function (e) {
  //   // app.globalData.userInfo = e.detail.userInfo
  //   // this.setData({
  //   //   userInfo: e.detail.userInfo,
  //   //   hasUserInfo: true
  //   // })
  //   this.login();
  // },
  login: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
      console.log(app.globalData.userInfo)
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {

        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  mitemClick: function (e) {
    if (this.data.hasUserInfo) {
      wx.navigateTo({
        url: e.currentTarget.dataset.url,
      })
    } else {
      app.alert({
        "msg": "未登录，请登录后重试",
        "code": "0"
      });
    }
  }
})