
// 同时发送异步代码的次数
let ajaxTimes=0;
export const request=(params)=>{
  var serverIp = "192.168.43.235";
  var port = "9087";

  ajaxTimes++;
  // 显示加载中 效果
  wx.showLoading({
    title: "加载中",
    mask: true
  });
    


  // 定义公共的url
  const baseUrl="http://"+serverIp+":"+port+"/";
  return new Promise((resolve,reject)=>{
    wx.request({
     ...params,
     dataType:"json",
     method:"POST",
     url:baseUrl+params.url,
     success:(result)=>{
       resolve(result.data);
     },
     fail:(err)=>{
       reject(err);
     },
     complete:()=>{
      ajaxTimes--;
      if(ajaxTimes===0){
        //  关闭正在等待的图标
        wx.hideLoading();
      }
     }
    });
  })
}